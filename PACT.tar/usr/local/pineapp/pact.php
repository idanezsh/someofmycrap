#!/usr/bin/php
<?
function extract_rcparm_file ($rcfile,$parm)
{
    $rcdata = file($rcfile);
    $tmp=preg_grep("/^$parm=/",$rcdata);
    foreach ($tmp as $v) {
	$t=explode("\"",$v);
         if (isset($t[1]))
    	    return $t[1];
         else
    	     return "";
    }
}



function SendErrorMail ($error, $cmd){

	//RCfiles to use for sending alerts
	$rcpact = "/etc/rc.pineapp/rc.pact";
	$rcsystem = "/etc/rc.pineapp/rc.system";
	
	//extracting parameter
	$doisendmail  = extract_rcparm_file($rcpact,"PACT_ENABLED");
	$whotosendto  = extract_rcparm_file($rcpact,"PACT_NOTIFY_EMAIL");
	$mailfrom     = extract_rcparm_file($rcpact,"PACT_NOTIFY_FROM");
	$localip      = extract_rcparm_file($rcsystem,"CLUSTER_UNIT_IP");
	$serialno=system('cat /usr/local/etc/PA_SN');
	$hostname=system('hostname');
	
	//sending mail
	$headers = 'From: PineApp Alerter <'.$mailfrom.'>' . "\r\n" .
    		'Return-Path: '.$mailfrom.'' . "\r\n" .
	       	'X-Mailer: PHP/' . phpversion();
	$to      = $whotosendto;
	$subject = 'Error on host:('.$hostname.') '.$slaves_ip_list[$i].' failed to SCP to director ('.$serialno.')';
/*	$message = "Hello Support,
This is $hostname Speaking
I could not scp to director :(
please check that the keys we're not replaced 
and that the ports are open
	
Slave IP is: $slaves_ip_list[$i]
Unit IP is: $localip
	
This is my error from restoreconf.log:
$error	
This is what i was trying to do:
$cmd";
*/
	$message = '
<table style="border:solid 1px #cccccc;" width="90%" border="0"
  cellpadding="0" cellspacing="0" align="center">
  <tbody>
    <tr>
      <td
style="background-color:#337ab7;padding:20px;color:#ffffff;font-family:verdana;font-size:x-large;"
        width="100%" align="bottom"><img alt="Encrypted Email"
src="/root/alert.png"
          height="120" width="103" border="0"> <nobr><b>Email
            Encryption<br>
          </b></nobr> <font face="Arial" size="3" color="#ffffff">
This is '$hostname' Speaking
I could not scp to director :(
please check that the keys were not replaced 
and that the ports are open.</font><nobr></nobr></td>
    </tr>
    <tr>
      <td style="background-color:#bdd5e6;padding:30px;" width="400"><font
          face="Arial" size="3" color="#000000"><span>You are sending an
            Encrypted Email</span>.<br class="">
          Slave IP is: '$slaves_ip_list[$i]'
Unit IP is: '$localip'
	
This is my error from restoreconf.log:
'$error'	
This is what i was trying to do:
'$cmd'"; <span class=""></span><a
            moz-do-not-send="true"
href="dontcare"
            class=""></a>
        </font> </td>
    </tr>
    <tr>
      <td style="background-color:#ffffff;padding:20px;" width="400"><a
          href="http://www.pineapp.com" target="_blank"> <font
            face="Arial" size="2" color="blue">PineApp</font></a><font
          face="Arial" size="2" color="#000000"> © 2016, All Rights
          Reserved. </font> </td>
    </tr>
  </tbody>
</table>

';



	
	//send the mail
	if ($doisendmail == "yes")
	{
	    $string_log = "Sending Email to $to ";
	    write_log($DEBUG_LEVEL,$string_log);
	    
	    mail($to, $subject, $message, $headers);
	
	} else {
	    $string_log = "Email will not be sent, /etc/rc.pineapp/rc.pact is set to NO";
	    write_log($DEBUG_LEVEL,$string_log);
	}
}
?>
