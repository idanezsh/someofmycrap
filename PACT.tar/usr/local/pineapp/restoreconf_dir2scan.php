#!/usr/bin/php
<?
/*
 * Modified by Alex Bar 2016
 */
/*   SCRIPT
1)creates configuration file
2)copies it to slaves
3)runs restore command in slaves
*/

include 'pact.php';

for ($i = 1; $i<count($argv); $i++)
if ($argv[$i] == '-d' && isset($argv[$i+1]))
$DEBUG_LEVEL = $argv[$i+1];

if (!isset($DEBUG_LEVEL))
$DEBUG_LEVEL = 0;


$script_index = "DIR2SCAN";
$log_file = "/var/log/restoreconf.log";
$_TMP_SLAVES_OUT_SYNC = "/tmp/_slaves_out_sync";
$_TMP_SLAVES_OUT_SYNC_LDAP = "/tmp/_slaves_out_sync_ldap";



$string_log = "\n ****    SCRIPT STARTS **** \n";
write_log($DEBUG_LEVEL,$string_log);



// Make sure there's only one instance of the script
$cmd = "ps -ef | grep 'restoreconf_dir2scan.php' | grep -v grep | wc -l";
$result = exec ($cmd);
if ($result > 1)
{
	write_log ($DEBUG_LEVEL, "Already running\n\n");
	die;
}





//require_once ("/usr/local/httpd/htdocs/manage/utility/pg_conn.php");

$CLUSTER_UNIT_IP = trim(exec('grep ^CLUSTER_UNIT_IP /etc/rc.pineapp/rc.system |cut -d \" -f 2'));

if (isset($argv[1]) && $argv[1]=='specialip' )
	$slaves_ip_list[0] = isset($argv[2]);
else
	$slaves_ip_list = get_slaves_ips();

$string_log = 'SLAVES IP ARE:'."\n".@implode("\n",$slaves_ip_list);
write_log($DEBUG_LEVEL,$string_log);

switch ($argv[1])
{
    case 'monit_start':
        if (is_file($_TMP_SLAVES_OUT_SYNC))
        $lines = @file($_TMP_SLAVES_OUT_SYNC);
        if (count($lines) > 0)
        {
            unlink($_TMP_SLAVES_OUT_SYNC);
            if (trim($lines[0]) == 'ALL')
            {
                $string_log = "\n RUN FOR ALL SLAVE IPs \n";
                write_log($DEBUG_LEVEL,$string_log);
                //echo "\nRUN FOR ALL\n";
                sync_db(-1);
            }
            else
            {
                $string_log = "\n RUN FOR SPECIAL IPs";
                write_log($DEBUG_LEVEL,$string_log);
                for ($i = 0; $i<count($lines); $i++)
                {
                    $slaves_ip_list[0] = trim($lines[$i]);
                    $string_log = "\n RUN FOR SPECIAL IP $slaves_ip_list[0] \n";
                    write_log($DEBUG_LEVEL,$string_log);
                    // echo "\nrun for $slaves_ip_list[0]\n";
                    sync_db($slaves_ip_list[0]);
                }
            }
        }
        else
        {
            $string_log = "\n ERROR EXIT (111) : NO FILE $_TMP_SLAVES_OUT_SYNC found \n";
            write_log($DEBUG_LEVEL,$string_log);
            exit("111"); // no file $_TMP_SLAVES_OUT_SYNC found
        }

        break;
    case 'sync_db':
        sync_db(-1);
        break;
    case 'specialip':
        $slaves_ip_list[0] = $argv[2];
        $ret = sync_db($argv[2]);
        if ($ret = 5)
        exit("5"); // wrong slave IP
        break;
    case 'setstatus':
        set_sync_status($argv[2]);
        break;

    case 'sync_bwl_actions':
        $slaves_ip_list = get_all_slaves();
        $type = $argv[2];
        $params = $argv[3];
        sync_bwl($type,$params,$slaves_ip_list);
        break;

    case 'monit_start_ldap':
        unlink($_TMP_SLAVES_OUT_SYNC_LDAP);
        $string_log = "\n RUN sync after LDAP ";
                write_log($DEBUG_LEVEL,$string_log);
      $slaves_ip_list = get_all_slaves();
      $connn = pg_connect("dbname=secure user=postgres" );
      $tmp_masq_plagin_data = "/tmp/tmp.addr_masq";
      if(is_file($tmp_masq_plagin_data))
      unlink($tmp_masq_plagin_data);
      pg_query($connn,"COPY plugins.address_based_masquerading TO '$tmp_masq_plagin_data'");

      $tmp_email_plagin_data = "/tmp/tmp.email_domain";
      if(is_file($tmp_email_plagin_data))
      unlink($tmp_email_plagin_data);
      pg_query($connn,"COPY plugins.email_to_domain TO '$tmp_email_plagin_data'");
      pg_close($connn);

      /* check if slaves may enter to master DB */
      rewrite_hba_conf($slaves_ip_list);

      for ($i = 0; $i < count($slaves_ip_list); $i++)
      {
        //$scp_str = "scp -P 7022 /tmp/directorconf.tar.gz root@$slaves_ip_list[$i]:/var/log/backup_conf_db/";
          $cmd = "scp -P 7022 $tmp_masq_plagin_data root@$slaves_ip_list[$i]:/tmp/";
          $string_log = "\n RUNNING FOR  $slaves_ip_list[$i] sync after LDAP:\n";
          write_log($DEBUG_LEVEL,$string_log);
          //exec($scp_str);
	  exec($cmd,$null,$return_code);
          if ($return_code != 0){
		  $error = "\n $cmd => returned FAILURE [ERROR:$return_code]";
                  write_log($DEBUG_LEVEL,$error);
		  SendErrorMail($error, $cmd);
		  continue;
	  }
	  write_log($DEBUG_LEVEL,"$cmd => returned SUCCESS");
		  
          $cmd = "scp -P 7022 $tmp_email_plagin_data root@$slaves_ip_list[$i]:/tmp/";
          $string_log = "\n RUNNING FOR  $slaves_ip_list[$i] sync after LDAP:\n$cmd ";
          write_log($DEBUG_LEVEL,$string_log);
          //exec($scp_str);
	  exec($cmd,$null,$return_code);
          if ($return_code != 0){
		  $error = "\n $cmd => returned FAILURE [ERROR:$return_code]";
		  SendErrorMail($error, $cmd);
		  continue;
	  }
	  write_log($DEBUG_LEVEL,"$cmd => returned SUCCESS");

          //$cmd = "ssh -p 7022 $slaves_ip_list[$i] /usr/local/pineapp/restore_confsql_scanners.php sync_after_ldap $CLUSTER_UNIT_IP -d $DEBUG_LEVEL &";
          $cmd = "ssh -p 7022 $slaves_ip_list[$i] /usr/local/pineapp/restore_confsql_scanners.php sync_after_ldap $CLUSTER_UNIT_IP -d $DEBUG_LEVEL";
          $string_log = "\n RUNNING FOR  $slaves_ip_list[$i] sync after LDAP:\n$cmd ";
          write_log($DEBUG_LEVEL,$string_log);
          //exec($cmd);
	  exec($cmd,$null,$return_code);
          if ($return_code != 0){
		  $error = "\n $cmd => returned FAILURE [ERROR:$return_code]";
                  write_log($DEBUG_LEVEL,$error);
		  SendErrorMail($error, $cmd);
	  }
	  write_log($DEBUG_LEVEL,"$cmd => returned SUCCESS");
      }

      $string_log = "\n Finish RUN sync after LDAP ";
      write_log($DEBUG_LEVEL,$string_log);
      break;
}



function write_log($DEBUG_LEVEL,$string_log)
{
    global $log_file,$script_index;
    $start_time = date("Y-m-d H:i:s");
    $fp = fopen($log_file,"a");
    fwrite($fp,$script_index." - $start_time  :".$string_log."\n");
    fclose($fp);
}



/*
Errors:
5 - wrong slave IP
11 - not found slaves needed sync
10 - /usr/local/pineapp/fixconf_scanner.php rewrite_slaves_rcinfo special /wrong IP probably
53 - it's already running(sync for this IP)
*/

/*
exec($scp_str,$null,$return_code);
if ($return_code != 0)
{
echo "SCP error\n";
*/

function sync_db($sp_ip)
{
    global $DEBUG_MODE,$slaves_ip_list;

    if ($sp_ip == -1)
    $RUN_FOR_ALL = 1;
    else
    $RUN_FOR_ALL = 0;

    $string_log = "\n function sync_db($sp_ip) RUN_FOR_ALL = $RUN_FOR_ALL\n";
        write_log($DEBUG_LEVEL,$string_log);

    if (count($slaves_ip_list) == 0)
    {
        //echo "Slaves needed sync were not found";
        $string_log = "\n ERROR EXIT (11) : Slaves needed sync were not found \n";
        write_log($DEBUG_LEVEL,$string_log);
        exit(11);
    }
    /* running check */
    for ($i = 0; $i<count($slaves_ip_list); $i++)
    {
        $running_file = "/tmp/_running_sync_".$slaves_ip_list[$i];
        if (is_file($running_file))
        ;
        else
        $tmp_slaves[]=$slaves_ip_list[$i];
    }
    $slaves_ip_list = $tmp_slaves;

    if ($RUN_FOR_ALL == 0)
    if (!in_array($sp_ip,$tmp_slaves))
    {
        $string_log = "\n ERROR EXIT (100) : ip SP=$sp_ip allredy running \n";
        write_log($DEBUG_LEVEL,$string_log);
        exit("100");//ip allredy running
    }

    if (count($slaves_ip_list)==0)
    {
        $string_log = "\n ERROR EXIT (100) : ip allredy running \n";
        write_log($DEBUG_LEVEL,$string_log);
        exit("120");//ip allredy running
    }

    if ($RUN_FOR_ALL == 0 )
    {
    	$pg_conn = pg_connect("dbname=secure user=pineapp password=V1ew5oni(") or die ("Unable to connect to db");
        $check = @pg_result(@pg_query("SELECT count(host_ip) as ip FROM firewall.fw_hosts as fw,lb.vipn_details as lb WHERE fw.host_id=lb.ip::integer AND lb.configuration=B'1' AND lb.mode=B'0' AND fw.host_ip='".$slaves_ip_list[0]."'"),0,0);
        pg_close($pg_conn);
        if (!isset($check) || $check != 1)
        {
            $string_log = "\n ERROR  (5) : IP ($slaves_ip_list[0]) is not slave IP \n";
            write_log($DEBUG_LEVEL,$string_log);
            return 5; //wrong slave ip
        }
    }



    $string_log = "\nRunning rc.files sync for slaves";
    write_log($DEBUG_LEVEL,$string_log);
    //echo "This slaves should be updated:";
    if ($RUN_FOR_ALL == 0 )
    $shell_com = "/usr/local/pineapp/fixconf_scanner.php rewrite_slaves_rcinfo special $sp_ip -d  $DEBUG_LEVEL";
    else
    $shell_com = "/usr/local/pineapp/fixconf_scanner.php rewrite_slaves_rcinfo -d $DEBUG_LEVEL";

    $string_log = "\nRunning $shell_com";
    write_log($DEBUG_LEVEL,$string_log);
    $ret = exec($shell_com,$null,$return_code);
    if ($ret != 0)
    {
        $string_log = "\nERROR on running rc.files sync for slaves\n.\nRemove all /tmp/_running_sync_ files.\n Script error stoped.";
        exec ("rm /tmp/_running_sync_*");

        write_log($DEBUG_LEVEL,$string_log);
        exit("10");
    }




    $fullconfname = "/etc/rc.pineapp/backup/directorconf.tar.gz";
    $shortconfname = "directorconf";
    $target_file = "/var/log/backup_conf_db/directorconf.tar.gz";

    /*    create current conf file  */
    //**************************** building dir for backup **********************************//
    $dir = "/tmp/scan_conf";
    exec("rm -rf $dir");
    exec("mkdir $dir");

    //echo "\nCreating archive for DB sync \n";


    //*********************************** backup  ******************************************//
    /*  restart sequances */
    $cmd = "/usr/local/pineapp/restart_sequances.php full";
    $string_log = "\nRunning $cmd";
    write_log($DEBUG_LEVEL,$string_log);
    exec($cmd);

    $file_list_tables = "/usr/local/pineapp/backup_confsql.list_sync";
    $lines = file($file_list_tables);
    for ($i = 0; $i < count($lines); $i++)
    {
        $tmp = explode(".",$lines[$i]);
        $schema = trim($tmp[0]);
        $tablename = trim($tmp[1]);

        /* get pg_dump version */
        $tmp = exec("pg_dump --version|cut -d ' ' -f 3");
        $tmp = substr($tmp,0,3);
        if ($tmp < 8.2)
        $version = 7;
        else
        $version = 8;

        if ($version == 7)
        {
            exec("pg_dump -a -U postgres secure -F t -f $dir/$schema.$tablename.dmp -t  $tablename  ");
            exec("pg_dump -a -U postgres secure -F p -f $dir/$schema.$tablename.p -t  $tablename  ");
        }
        else
        {
            exec("pg_dump -a -U postgres secure -F t -f $dir/$schema.$tablename.dmp -t  $schema.\\\"$tablename\\\" ");
            exec("pg_dump -a -U postgres secure -F p -f $dir/$schema.$tablename.p -t  $schema.\\\"$tablename\\\" ");
        }


        //`pg_dump -a -U postgres secure -F t -f $dir/$schema.$tablename.dmp -t  $tablename  `;
        // `pg_dump -a -U postgres secure -F p -f $dir/$schema.$tablename.p -t  $tablename  `;

    }
    /* archive */
    $shell_com = "tar cfz /tmp/directorconf.tar.gz $dir //1>/dev/null 2>/dev/null ";
    $string_log = "\nRunning $shell_com";
    write_log($DEBUG_LEVEL,$string_log);
    exec($shell_com);
	$arr_ip_for_remove = array();

if ($RUN_FOR_ALL == 0 ) {
	$slaves_ip_list = reset($slaves_ip_list);
	$slaves_ip_list = array();
	$slaves_ip_list[0] = $sp_ip;
}
	//system ('echo "'.count($slaves_ip_list).'" >> /tmp/_response_code_');
    for ($i = 0; $i < count($slaves_ip_list); $i++)
    {
        //send_params_list
        $scp_str = "scp -P 7022 /tmp/directorconf.tar.gz root@$slaves_ip_list[$i]:/var/log/backup_conf_db/";
        $string_log = "\nRunning $scp_str";
        write_log($DEBUG_LEVEL,$string_log);

        exec($scp_str,$null,$return_code);
        if ($return_code != 0) {
            $string_log = "ERROR (200)  - scp error on ".$slaves_ip_list[$i]."(return_code = $return_code)\n";
            set_not_sync_status($slaves_ip_list[$i]);
            write_log($DEBUG_LEVEL,$string_log);
            $arr_ip_for_remove[] = $slaves_ip_list[$i];
            $running_file = "/tmp/_running_sync_".$slaves_ip_list[$i];
            exec("rm $running_file");
            //exit(200);
            $string_log = "remove $running_file\n";
            write_log($DEBUG_LEVEL,$string_log);
	    $scperror = "ERROR (200)  - scp error on ".$slaves_ip_list[$i]."(return_code = $return_code)\n";
	    SendErrorMail($scperror, $scp_str);
        }
    }
    $slaves_ip_list = array_diff($slaves_ip_list,$arr_ip_for_remove);
    foreach ($slaves_ip_list as $val)
    {
    	//system ('echo "'.$val.'" >> /tmp/_response_code_');
        //run rewrite_rcfiles in slaves
        //$scp_str = "ssh -p 7022 $slaves_ip_list[$i] /usr/local/pineapp/restoreconf $shortconfname ";
        $scp_str = "ssh -p 7022 $val tar xfz  /var/log/backup_conf_db/directorconf.tar.gz --directory=/var/log/backup_conf_db/ 1>/dev/null 2>/dev/null";
        $string_log = "\nRunning $scp_str";
        write_log($DEBUG_LEVEL,$string_log);
        exec($scp_str,$null,$return_code);
        if ($return_code != 0)
        {
            $string_log = "ERROR EXIT (210) - runing error(return_code = $return_code)\n";
            set_not_sync_status($val);
            write_log($DEBUG_LEVEL,$string_log);
            //system ('echo "210 '.$responce.'" >> /tmp/_response_code_');
	    exit(210);
        }

        $cmd = "ssh -p 7022 $val /usr/local/pineapp/restore_confsql_scanners.php sync_local_db -d $DEBUG_LEVEL &";
        $string_log = "\nRunning $cmd";
        write_log($DEBUG_LEVEL,$string_log);
        $responce = trim(exec($cmd,$null,$return_code));
        if ($responce == 999)
        {
            set_sync_status($val);
            $string_log = "\nSYNC for $val finish SUCCESS\n";
            write_log($DEBUG_LEVEL,$string_log);
        }

        elseif ($responce == 911)
        {
            $string_log = "\nSYNC for $val finish - FAILED - Instance of resore_confsql_scanners.php already is running\n ";
            write_log($DEBUG_LEVEL,$string_log);
            unlink("/tmp/_running_sync_$val");
        }
        else
        {
            $string_log = "\nSYNC for $val finish - FAILED \n ";
            write_log($DEBUG_LEVEL,$string_log);
            unlink("/tmp/_running_sync_$val");
        }

        //system ('echo "'.$return_code.' '.$responce.'" >> /tmp/_response_code_');
        if ($return_code != 0)
        {
            $string_log = "ERROR EXIT (220) - running error(return_code = $return_code)\n";
            set_not_sync_status($val);
            write_log($DEBUG_LEVEL,$string_log);
            //system ('echo "220 '.$responce.'" >> /tmp/_response_code_');
            exit(220);
        }
    }
}

function get_slaves_ips()
{
	$pg_conn = pg_connect("dbname=secure user=pineapp password=V1ew5oni(") or die ("Unable to connect to db");
    $res = pg_query("SELECT host_ip as ip FROM firewall.fw_hosts as fw,lb.vipn_details as lb WHERE fw.host_id=lb.ip::integer AND lb.configuration=B'1' AND lb.mode=B'0' AND lb.status<>B'1'");
    $num_rows = pg_num_rows($res);
    for ($i = 0; $i < $num_rows; $i++)
    	$array_ips[$i] = pg_result($res,$i,'ip');
	pg_close($pg_conn);
    return $array_ips;
}
function get_all_slaves()
{
	$pg_conn = pg_connect("dbname=secure user=pineapp password=V1ew5oni(") or die ("Unable to connect to db");
    $res = pg_query("SELECT host_ip as ip FROM firewall.fw_hosts as fw,lb.vipn_details as lb WHERE fw.host_id=lb.ip::integer AND lb.configuration=B'1' AND lb.mode=B'0' ");
    $num_rows = pg_num_rows($res);
    for ($i = 0; $i < $num_rows; $i++)
    	$array_ips[$i] = pg_result($res,$i,'ip');
	pg_close($pg_conn);
    return $array_ips;
}
function call_to_sync()
{
    global $CLUSTER_UNIT_IP;
}
function set_sync_status_old($slave_ip_id)
{
	$pg_conn = pg_connect("dbname=secure user=pineapp password=V1ew5oni(") or die ("Unable to connect to db");
    $ip = trim(pg_result(pg_query("SELECT host_ip FROM firewall.fw_hosts WHERE host_id=$slave_ip_id"),0,0));
    unlink("/tmp/_running_sync_$ip");
    $query = "UPDATE lb.vipn_details SET status=B'1', gstatus=1 WHERE ip='".$slave_ip_id."'";
    //echo "\n$query\n";
    pg_query($query);
    pg_close($pg_conn);
}
function set_sync_status($slave_ip_id)
{
	$pg_conn = pg_connect("dbname=secure user=pineapp password=V1ew5oni(") or die ("Unable to connect to db");
    $ip = $slave_ip_id;
    $slave_ip_id = pg_result(pg_query("SELECT host_id FROM firewall.fw_hosts WHERE host_ip='".$ip."'"),0,0);
    unlink("/tmp/_running_sync_$ip");
    $query = "UPDATE lb.vipn_details SET status=B'1', gstatus=1 WHERE ip='".$slave_ip_id."'";
    pg_query($query);
    pg_close($pg_conn);
}
function set_not_sync_status($ip)
{
	$pg_conn = pg_connect("dbname=secure user=pineapp password=V1ew5oni(") or die ("Unable to connect to db");
	$slave_ip_id = pg_result(pg_query("SELECT host_id FROM firewall.fw_hosts WHERE host_ip='".$ip."'"),0,0);
	$query = "UPDATE lb.vipn_details SET status=B'0', gstatus=1 WHERE ip='".$slave_ip_id."'";
	pg_result(pg_query("UPDATE lb.vipn_details SET status=B'0', gstatus=1 WHERE ip='".$slave_ip_id."'"));
	//pg_query($query);
	pg_close($pg_conn);
}

function sync_bwl($type,$params,$slaves_ip_list)
{
    for ($i = 0; $i< count($slaves_ip_list); $i++)
    {
        //$cmd = "ssh -p 7022 $slaves_ip_list[$i] /usr/local/pineapp/restore_confsql_scanners.php sync_bwl_command  $type $params -d $DEBUG_LEVEL &";
        $cmd = "ssh -p 7022 $slaves_ip_list[$i] /usr/local/pineapp/restore_confsql_scanners.php sync_bwl_command  $type $params -d $DEBUG_LEVEL";
        $string_log = "\nRunning $cmd";
        write_log($DEBUG_LEVEL,$string_log);
	#$responce = trim(exec($cmd,$null,$return_code));
        $responce = exec($cmd,$null,$return_code);
        //if ($responce == 0)
        if ($return_code == 0)
	{
    	    $string_log = "\n return Success\n Script Stoped  . . \n";
	} else {
    	    $string_log = "\n return: Script Stoped [ERROR: ssh has failed return_code=$return_code] ... \n";
	    SendErrorMail($string_log, $cmd);
	}
        write_log($DEBUG_LEVEL,$string_log);
    }
}


function rewrite_hba_conf($slave_ip_array)
{
    // this function checked pg_hba file -  it has to contain slaves ip, if not the script adds them to it
    global $DEBUG_LEVEL;
    $pg_hba_conf_current = "/var/data/db/pg_hba.conf";
    $pg_hba_conf_template = "/usr/local/pineapp/templates/pg_hba.conf";

    $lines = file($pg_hba_conf_current);

    $current_hosts = array();
    for ($i = 0; $i < count($lines); $i++)
    {
        $arr_new = array();
        $arr_tmp = array();
        if( preg_match("/^host\s+all\s+all*+/",$lines[$i]))
        {
            //echo $lines[$i];
            $arr_tmp = explode( " ",$lines[$i]);
            // print_r($arr);
            for ($x = 0; $x < count($arr_tmp); $x++)
            if ($arr_tmp[$x] != "")
            $arr_new[] = $arr_tmp[$x] ;

            if ($arr_new[4] == '255.255.255.0')
            $current_hosts[] = $arr_new[3];
        }
    }
    $rewrite_pg_conf = 0;

    $array_ip_add = array();
    for ($i = 0; $i < count($slave_ip_array); $i++)
    {
    if (!in_array($slave_ip_array[$i],$current_hosts))
    $array_ip_add[] = $slave_ip_array[$i];


    }

    if (count($array_ip_add) > 0)
    {
        write_log($DEBUG_LEVEL,"File pg_hba.conf needs to be rewriten");


        $tmp_conf = "/tmp/postgresql.conf.tmp";
        echo "\n file need to be rewritten\n";
        $lines = array();
        // rewrite file
        $lines = file($pg_hba_conf_template);

        //for ($i = 0; $i < count($array_ip_add); $i++)
        //$lines[] = 'host     all        all        '.$array_ip_add[$i].'      255.255.255.0   trust'."\n";
        for ($i = 0; $i < count($slave_ip_array); $i++)
        $lines[] = 'host     all        all        '.$slave_ip_array[$i].'      255.255.255.0   trust'."\n";


        $fp = fopen($tmp_conf,"w");
        for ($i = 0; $i < count($lines); $i++)
        fwrite ($fp,$lines[$i]);

        fclose($fp);

        if ($DEBUG_LEVEL == 0)
        {
            exec("cp $tmp_conf $pg_hba_conf_current");
            exec ("chown postgres.sshd $pg_hba_conf_current");

            restart_db();
        }
    }
    else
    write_log($DEBUG_LEVEL,"No need to rewrite pg_hba.conf ");

    return(1);
}

function restart_db()
{
    global $DEBUG_LEVEL;
        $reload_conf_db = "killall -1 postgres";
    exec ($reload_conf_db);
    sleep(2);
    exec ($reload_conf_db);
    write_log($DEBUG_LEVEL," DB Configuration Reload . . . ");
    return true;
    /*
    write_log($DEBUG_LEVEL," DB Restart . . . ");
    $pg_stop  = "/etc/rc.d/pgres stop ";
    $pg_start = "/etc/rc.d/pgres start &";

    echo " \n Running $pg_stop \n";
    exec($pg_stop,$null,$return_code);
    echo "\nreturn_code=$return_code\n SLEEP (5) \n";
    sleep(5);
    echo " \n Running $pg_start\n";
    exec($pg_start,$null,$return_code);
    echo "\nreturn_code=$return_code\n SLEEP (5) \n";
    sleep(5);

    // check if postgres up

    $count_pg = 0;
    while (!check_pg_status())
    {
        if ($count_pg > 20)
        break;

        echo "\n pg is not up(count=$count_pg). \n Trying restart again...";
        write_log($DEBUG_LEVEL," PG is not up. \n Trying restart again...");

        exec($pg_stop);
        sleep(2);
        exec($pg_start);
        sleep(7);
        $count_pg++;
    }

    if ($count_pg < 20)
    {
        echo "\n PG is UP after $count_pg try \n";
        write_log($DEBUG_LEVEL," PG is UP after $count_pg try . . .",1);
        return true;
    }
    else
    {
        die( "\n Postgres failed to start . . .\n");
        write_log($DEBUG_LEVEL," Postgres failed to start . . .",1);
        return false;
    }
    */
}

/*function check_pg_status()
{
    //if (trim(exec("pstree|grep postgres|wc -l")) >0)
    if (pg_connect("dbname=secure user=pineapp password=V1ew5oni(") )
    {
        pg_close();
        return true;
    }
    else
    return false;

}*/



//if ($DEBUG_MODE > 0)
//echo "\nEnd of restoreconf_dir2scan.php Script\n";
exit("0");


?>
