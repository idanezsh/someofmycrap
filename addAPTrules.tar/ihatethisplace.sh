#/bin/bash

#attaching victimid from file to one APTblocker rule

chmod -x /usr/local/pineapp/pamon.d/mail_policyd.sh
killall -9 mail_policyd



for vid in `psql secure postgres -t -c "SELECT g.oid FROM pineapp.objects as o LEFT JOIN gui.module_license_per_user as g ON (o.oid=g.oid) WHERE g.mid=4 and o.deleted='f'"`; do
echo $vid

psql secure postgres -c "insert into policy.attachment_rules (direction,check_type,attribute,extension_group_id,extension_id,min_size,action_id_type,action_id,forward_id,mirror_id,notify_id,enabled) values (1,3,15,-1,-1,0,328448,-1,-1,-1,-1,1);"
		
psql secure postgres -c "insert into policy.user_attachment_rules (victim_id,rule_id) values ($vid,(select last_value from policy.attachment_rules_id_seq))"

lastval=`psql secure postgres -t -c "select last_value from policy.attachment_rules_id_seq"`
echo "created APT rule for oid= $vid rulenum=$lastval " >> createdrules.txt;
done
	
		
chmod +x /usr/local/pineapp/pamon.d/mail_policyd.sh
/usr/local/pineapp/pamon.d/mail_policyd.sh start
sleep 1
monit

echo "i hate you, goodbye! (check file createdrules.txt)"
