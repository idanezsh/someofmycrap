#!/bin/bash
#SERS=`psql secure postgres -t -c "select count(*) from pineapp.objects where deleted='f'"`;
USERS=`ls -al /var/data/popboxes/ | wc -l`;

echo $USERS
if [[ "$USERS" -lt "301" ]]; then
	       /root/Idan/swaks -f alert@ganshmuel.org.il -t idan@pineapp.com,support@pineapp.com --h-Subject "This is ALERT from ganshmuel" -s 127.0.0.1 --body "mailbox count is under 296 check real number and see if someone deleted something"
	       tar cvf /root/Idan/doomsday.tar /var/log/apache/error_log /var/log/apache/access_log /var/log/crontab_errors.log /var/log/crontab_extended.log /var/log/restoreconf.log /var/log/syslog.log
	       chmod -x /root/Idan/checkusers.sh
	       echo `date` >> /root/Idan/out
	else
	        echo "done"
fi
		
